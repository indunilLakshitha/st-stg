<x-market-layout>
    <livewire:marketplace.order.history>
</x-market-layout>
