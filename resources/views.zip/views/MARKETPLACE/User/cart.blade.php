<x-market-layout>
    <livewire:marketplace.user.cart.cart-index>
</x-market-layout>
