<x-app-layout>
    <livewire:marketplace.admin.product.category.category />
    </ x-app-layout>
