@section('title', 'Admin Users | Edit')
<x-app-layout>
    <livewire:admin.admin.update-admin id="{{ $id }}" />
    </ x-app-layout>
