@section('title', 'Customers | Team View')
<x-app-layout>
    <livewire:admin.team.index />
    </ x-app-layout>
