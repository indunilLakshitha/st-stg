<x-app-layout>
    <livewire:profile.create-profile />
    </ x-app-layout>
