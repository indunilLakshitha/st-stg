<x-app-layout>
    <livewire:profile.profile />
    </ x-app-layout>
