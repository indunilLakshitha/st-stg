@section('title', 'Course | Edit')
<x-app-layout>
    <livewire:admin.courses.course.update-course id="{{ $id }}" />
    </ x-app-layout>
