@section('title', 'Customers | Edit')
<x-app-layout>
    <livewire:user.user-edit id="{{ $id }}" />
    </ x-app-layout>
