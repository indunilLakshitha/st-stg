@section('title', 'Customers | Registration Requests')
<x-app-layout>
    <livewire:admin.customers.registration-request />
    </ x-app-layout>

