
<x-home-layout>

    <livewire:home.checkout user_id="{{ $user_id }}" />

    </ x-home-layout>
