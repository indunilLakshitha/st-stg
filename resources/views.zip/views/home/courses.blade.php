@section('title', 'Courses')
<x-home-layout>

    <livewire:home.courses referral_id="{{ $ref }}" />

    </ x-home-layout>
