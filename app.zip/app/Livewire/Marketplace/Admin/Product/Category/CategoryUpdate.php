<?php

namespace App\Livewire\Marketplace\Admin\Product\Category;

use Livewire\Component;

class CategoryUpdate extends Component
{
    public function render()
    {
        return view('livewire.marketplace.admin.product.category.category-update');
    }
}
