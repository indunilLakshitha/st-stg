<?php

namespace App\Livewire\Marketplace\Admin\Product\SubCategory;

use Livewire\Component;

class SubCategoryUpdate extends Component
{
    public function render()
    {
        return view('livewire.marketplace.admin.product.sub-category.sub-category-update');
    }
}
