<?php

namespace App\Traits;


trait CustomerPermissionTrait
{
    
    public function setNotActivatedPermissions(){

    }
}
