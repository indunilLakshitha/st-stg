<?php

namespace App\Exceptions;

use Exception;

class PathNotSetException extends Exception
{
    //
}
