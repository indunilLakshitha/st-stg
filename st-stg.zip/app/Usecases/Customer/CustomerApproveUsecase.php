<?php

namespace App\Usecases\Customer;

use App\Enums\ResponseString;
use App\Exceptions\OutstandingMaximumExceedException;
use App\Models\CommonWhitelist;
use App\Models\ShopSetting;

class CustomerApproveUsecase
{
    public function handle(){
        
    }
}
