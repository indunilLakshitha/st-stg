<?php

namespace App\Livewire\Admin\Customers;

use Livewire\Component;

class TeamView extends Component
{
    public function render()
    {
        return view('livewire.admin.customers.team-view');
    }
}
