<?php

namespace App\Livewire\Admin\Payment;

use Livewire\Component;

class SalesReport extends Component
{
    public function render()
    {
        return view('livewire.admin.payment.sales-report');
    }
}
