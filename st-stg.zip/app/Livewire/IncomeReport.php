<?php

namespace App\Livewire;

use Livewire\Component;

class IncomeReport extends Component
{
    public function render()
    {
        return view('livewire.income-report');
    }
}
