<?php

namespace App\Livewire\Marketplace\Admin\Product\Product;

use Livewire\Component;

class ProductUpdate extends Component
{
    public function render()
    {
        return view('livewire.marketplace.admin.product.product.product-update');
    }
}
