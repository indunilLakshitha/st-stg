<?php

namespace App\Livewire\Course;

use Livewire\Component;

class CourseCreate extends Component
{
    public function render()
    {
        return view('livewire.course.course-create');
    }
}
