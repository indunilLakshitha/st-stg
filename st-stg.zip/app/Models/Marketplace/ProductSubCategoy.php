<?php

namespace App\Models\Marketplace;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductSubCategoy extends Model
{
    use HasFactory;

    protected $table = 'sub_categories';
}
