@section('title', 'Courses ')<x-app-layout>
    <livewire:admin.courses.course.courses />
    </ x-app-layout>
