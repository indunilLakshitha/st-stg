@section('title', 'Course | Categories')
<x-app-layout>
    <livewire:admin.courses.category.categories />
    </ x-app-layout>
