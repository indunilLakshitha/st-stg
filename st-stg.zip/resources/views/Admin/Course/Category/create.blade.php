@section('title', 'Course | Categories | Add')
<x-app-layout>
    <livewire:admin.courses.category.create-category />
    </ x-app-layout>
