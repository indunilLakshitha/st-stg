@section('title', 'Course | Categories | Edit')
<x-app-layout>
    <livewire:admin.courses.category.update-category id="{{ $id }}" />
    </ x-app-layout>
