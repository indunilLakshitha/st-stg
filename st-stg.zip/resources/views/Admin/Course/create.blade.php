@section('title', 'Course | Add')
<x-app-layout>
    <livewire:admin.courses.course.create-course />
    </ x-app-layout>
