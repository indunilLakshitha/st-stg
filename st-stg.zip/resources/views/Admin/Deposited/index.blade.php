@section('title', 'Withdrawal | Deposited')
<x-app-layout>
    <livewire:admin.deposited.deposited />
    </ x-app-layout>
