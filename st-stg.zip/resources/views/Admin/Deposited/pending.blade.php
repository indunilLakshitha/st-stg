@section('title', 'Withdrwal | Requests')

<x-app-layout>
    <livewire:admin.deposited.pending />
    </ x-app-layout>
