@section('title', 'Sales | All')

<x-app-layout>
    <livewire:admin.sales.index />
    </ x-app-layout>
