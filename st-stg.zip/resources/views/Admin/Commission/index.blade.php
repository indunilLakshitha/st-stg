@section('title', 'Comission | List')
<x-app-layout>
    <livewire:admin.commission.commission />
    </ x-app-layout>
