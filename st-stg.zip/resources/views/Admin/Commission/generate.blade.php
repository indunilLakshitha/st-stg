@section('title', 'Comission | Generate')

<x-app-layout>
    <livewire:admin.commission.generate-commision />
    </ x-app-layout>
