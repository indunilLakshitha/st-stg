@section('title', 'Admin Users | Add')
<x-app-layout>
    <livewire:admin.admin.create-admin />
    </ x-app-layout>
