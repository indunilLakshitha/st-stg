@section('title', 'Admin Users | All')
<x-app-layout>
    <livewire:admin.admin.admins />
    </ x-app-layout>
