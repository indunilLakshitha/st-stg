@section('title', 'Passowrd')
<x-app-layout>
    <livewire:admin.password.index />
    </ x-app-layout>
