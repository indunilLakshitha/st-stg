@section('title', 'Passowrd | Update')
<x-app-layout>
    <livewire:admin.password.edit id="{{ $id }}" />
    </ x-app-layout>
u
