@section('title', 'Settings')
<x-app-layout>
    <livewire:admin.settings.index />
    </ x-app-layout>
