<x-app-layout>
    <livewire:profile.edit-profile userId="{{ $id }}" />
    </ x-app-layout>
