@section('title', 'Customers | All')
<x-app-layout>
    <livewire:admin.customers.customers />
    </ x-app-layout>
