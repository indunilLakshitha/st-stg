<x-app-layout>
    <livewire:user.user-create />
    </ x-app-layout>
