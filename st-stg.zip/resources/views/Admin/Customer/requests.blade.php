@section('title', 'Customers | Pending Activations')
<x-app-layout>
    <livewire:admin.customers.requests />
    </ x-app-layout>
