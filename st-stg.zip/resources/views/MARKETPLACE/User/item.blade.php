<x-market-layout>
    <livewire:marketplace.user.item id="{{ $slug }}">
</x-market-layout>
