{{-- <x-market-layout> --}}
    <livewire:marketplace.user.index cat="{{ $cat }}">

{{-- </x-market-layout> --}}
