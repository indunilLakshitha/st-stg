<x-app-layout>
    <livewire:marketplace.admin.product.category.category-create />
    </ x-app-layout>
