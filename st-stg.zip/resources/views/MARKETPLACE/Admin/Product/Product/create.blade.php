<x-app-layout>
    <livewire:marketplace.admin.product.product.product-create />
    </ x-app-layout>
