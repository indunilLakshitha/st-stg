@section('title', 'My Team | Not Approved')
<x-app-layout>
    <livewire:referral.pending />
    </ x-app-layout>
