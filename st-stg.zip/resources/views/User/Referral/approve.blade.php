@section('title', 'My Team | Not Approved')
<x-app-layout>
    <livewire:referral.approve id="{{ $id }}" />
    </ x-app-layout>
