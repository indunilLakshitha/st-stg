@section('title', 'Courses | All')
<x-app-layout>
    <livewire:course.courses />
    </ x-app-layout>
