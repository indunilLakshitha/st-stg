<x-app-layout>
    <livewire:course.course-create />
    </ x-app-layout>
