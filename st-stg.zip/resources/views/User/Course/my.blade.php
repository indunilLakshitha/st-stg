@section('title', 'Courses | My Courses')
<x-app-layout>
    <livewire:course.my-courses />
    </ x-app-layout>
