@section('title', 'Courses | View')
<x-app-layout>
    <livewire:course.course-detail courseId="{{ $courseId }}" />
    </ x-app-layout>
