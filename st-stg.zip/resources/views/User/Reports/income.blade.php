@section('title', 'Reports | Income Report')
<x-app-layout>
    <livewire:reports.income-report />
    </ x-app-layout>
