<x-guest-layout>
    @section('title', 'Register')
    <livewire:register.customer-register referral_id="{{ $ref }}" />
</x-guest-layout>
