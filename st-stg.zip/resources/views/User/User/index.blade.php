<x-app-layout>
    <livewire:user.user-list />
    </ x-app-layout>
