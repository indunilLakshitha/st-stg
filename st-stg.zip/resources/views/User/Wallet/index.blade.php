@section('title', 'Wallet')
<x-app-layout>
    <livewire:wallet.wallet />
    </ x-app-layout>
