@section('title', 'My Team | Tree')
<x-app-layout>
    <livewire:tree.my />
    </ x-app-layout>
