@section('title', 'My Team | Pending Activations')
<x-app-layout>
    <livewire:my-team.pending-activations />
    </ x-app-layout>
