@section('title', 'My Team | Direct Team')
<x-app-layout>
    <livewire:my-team.direct-team />
    </ x-app-layout>
