@section('title', 'My Team | Sales Chart')
<x-app-layout>
    <livewire:my-team.sales-chart />
    </ x-app-layout>
