
<x-home-layout>

    <livewire:home.register referral_id="{{ $ref }}" course_id="{{ $course }}" />

    </ x-home-layout>
