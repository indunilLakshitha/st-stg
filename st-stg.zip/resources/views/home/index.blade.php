@section('title', 'Dashboard')
<x-home-layout>

    <livewire:home.index />

    </ x-home-layout>
